## 小游戏关系链互动后台示例代码

## quickstart
1. 安装依赖 `npm install`
2. 修改`config/index.js`中的`APPID`和`SECRET`为你的`APPID`和`SECRET`
3. 启动服务 `npm run start`