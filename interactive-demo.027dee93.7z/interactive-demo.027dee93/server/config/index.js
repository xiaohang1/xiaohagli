module.exports = {
    APPID: '你的小游戏APPID',
    SECRET: '你的小游戏SECRET'
}